﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// GrayScaleImageProcessingRC1.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_GrayScaleImageProcessingRC1TYPE 130
#define IDD_CONSTANT                    310
#define IDD_RADIUS                      312
#define IDC_EDIT_CONSTANT               1000
#define IDC_EDIT_RADIUS                 1001
#define ID_32771                        32771
#define IDM_EQUAL_IMAGE                 32772
#define ID_32773                        32773
#define ID_ADD_IMAGE                    32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define ID_32788                        32788
#define ID_32789                        32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_OP_IMAGE                     32796
#define ID_BLACK_IMAGE                  32797
#define ID_OR_IMAGE                     32798
#define ID_AND_IMAGE                    32799
#define ID_XOR                          32800
#define ID_                             32801
#define ID_XOR_IMAGE                    32802
#define ID_INVALUE_IMAGE                32803
#define ID_EMBOSS_IMAGE                 32804
#define ID_BLUR_IMAGE                   32805
#define ID_SHARPNING_IMAGE              32806
#define ID_HIFIL_IMAGE                  32807
#define ID_EDGE_IMAGE                   32808
#define ID_32809                        32809
#define ID_32810                        32810
#define ID_32811                        32811
#define ID_32812                        32812
#define ID_HOREDGE_IMAGE                32813
#define ID_VEREDGE_IMAGE                32814
#define ID_SIMCAL_IMAGE                 32815
#define ID_DIVCAL_IMAGE                 32816
#define ID_ZOOMOUT_IMAGE                32817
#define ID_ZOOMIN_IMAGE                 32818
#define ID_MOVE_IMAGE                   32819
#define ID_ROTATE_IMAGE                 32820
#define ID_32821                        32821
#define ID_32822                        32822
#define ID_UDMIRROR_IMAGE               32823
#define ID_LRMIRROR_IMAGE               32824
#define ID_32825                        32825
#define ID_32826                        32826
#define ID_32827                        32827
#define ID_32828                        32828
#define ID_ROTATE2_IMAGE                32829
#define ID_STREACH_IMAGE                32830
#define ID_EDDIN_IMAGE                  32831
#define ID_HISTOEQUAL_IMAGE             32832

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32833
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
