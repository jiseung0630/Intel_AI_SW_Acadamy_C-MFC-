﻿// CXYConstantDlg.cpp: 구현 파일
//

#include "pch.h"
#include "GrayScaleImageProcessingRC1.h"
#include "afxdialogex.h"
#include "CXYConstantDlg.h"


// CXYConstantDlg 대화 상자

IMPLEMENT_DYNAMIC(CXYConstantDlg, CDialogEx)

CXYConstantDlg::CXYConstantDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_XYCONSTANT, pParent)
	, m_X(0)
	, m_Y(0)
{

}

CXYConstantDlg::~CXYConstantDlg()
{
}

void CXYConstantDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_X);
	DDV_MinMaxInt(pDX, m_X, 0, INT_MAX);
	DDX_Text(pDX, IDC_EDIT2, m_Y);
	DDV_MinMaxInt(pDX, m_Y, 0, INT_MAX);
}


BEGIN_MESSAGE_MAP(CXYConstantDlg, CDialogEx)
END_MESSAGE_MAP()


// CXYConstantDlg 메시지 처리기
