﻿
// GrayScaleImageProcessingRC1View.cpp: CGrayScaleImageProcessingRC1View 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "GrayScaleImageProcessingRC1.h"
#endif

#include "GrayScaleImageProcessingRC1Doc.h"
#include "GrayScaleImageProcessingRC1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CGrayScaleImageProcessingRC1View

IMPLEMENT_DYNCREATE(CGrayScaleImageProcessingRC1View, CView)

BEGIN_MESSAGE_MAP(CGrayScaleImageProcessingRC1View, CView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_COMMAND(IDM_EQUAL_IMAGE, &CGrayScaleImageProcessingRC1View::OnEqualImage)
	ON_COMMAND(ID_ADD_IMAGE, &CGrayScaleImageProcessingRC1View::OnAddImage)
	ON_COMMAND(ID_OP_IMAGE, &CGrayScaleImageProcessingRC1View::OnOpImage)
	ON_COMMAND(ID_BLACK_IMAGE, &CGrayScaleImageProcessingRC1View::OnBlackImage)
	ON_COMMAND(ID_OR_IMAGE, &CGrayScaleImageProcessingRC1View::OnOrImage)
	ON_COMMAND(ID_AND_IMAGE, &CGrayScaleImageProcessingRC1View::OnAndImage)
	ON_COMMAND(ID_XOR_IMAGE, &CGrayScaleImageProcessingRC1View::OnXorImage)
	ON_COMMAND(ID_INVALUE_IMAGE, &CGrayScaleImageProcessingRC1View::OnInvalueImage)
	ON_COMMAND(ID_EMBOSS_IMAGE, &CGrayScaleImageProcessingRC1View::OnEmbossImage)
	ON_COMMAND(ID_BLUR_IMAGE, &CGrayScaleImageProcessingRC1View::OnBlurImage)
	ON_COMMAND(ID_SHARPNING_IMAGE, &CGrayScaleImageProcessingRC1View::OnSharpningImage)
	ON_COMMAND(ID_HIFIL_IMAGE, &CGrayScaleImageProcessingRC1View::OnHifilImage)
	ON_COMMAND(ID_HOREDGE_IMAGE, &CGrayScaleImageProcessingRC1View::OnHoredgeImage)
	ON_COMMAND(ID_VEREDGE_IMAGE, &CGrayScaleImageProcessingRC1View::OnVeredgeImage)
	ON_COMMAND(ID_SIMCAL_IMAGE, &CGrayScaleImageProcessingRC1View::OnSimcalImage)
	ON_COMMAND(ID_DIVCAL_IMAGE, &CGrayScaleImageProcessingRC1View::OnDivcalImage)
	ON_COMMAND(ID_ZOOMOUT_IMAGE, &CGrayScaleImageProcessingRC1View::OnZoomoutImage)
	ON_COMMAND(ID_ZOOMIN_IMAGE, &CGrayScaleImageProcessingRC1View::OnZoominImage)
	ON_COMMAND(ID_ROTATE_IMAGE, &CGrayScaleImageProcessingRC1View::OnRotateImage)
	ON_COMMAND(ID_ROTATE2_IMAGE, &CGrayScaleImageProcessingRC1View::OnRotate2Image)
	ON_COMMAND(ID_UDMIRROR_IMAGE, &CGrayScaleImageProcessingRC1View::OnUdmirrorImage)
	ON_COMMAND(ID_LRMIRROR_IMAGE, &CGrayScaleImageProcessingRC1View::OnLrmirrorImage)
	ON_COMMAND(ID_STREACH_IMAGE, &CGrayScaleImageProcessingRC1View::OnStreachImage)
	ON_COMMAND(ID_EDDIN_IMAGE, &CGrayScaleImageProcessingRC1View::OnEddinImage)
	ON_COMMAND(ID_HISTOEQUAL_IMAGE, &CGrayScaleImageProcessingRC1View::OnHistoequalImage)
END_MESSAGE_MAP()

// CGrayScaleImageProcessingRC1View 생성/소멸

CGrayScaleImageProcessingRC1View::CGrayScaleImageProcessingRC1View() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CGrayScaleImageProcessingRC1View::~CGrayScaleImageProcessingRC1View()
{
}

BOOL CGrayScaleImageProcessingRC1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CGrayScaleImageProcessingRC1View 그리기

void CGrayScaleImageProcessingRC1View::OnDraw(CDC* pDC)
{
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.
	unsigned char R, G, B;
	for (int i = 0; i < pDoc->m_inH; i++) {
		for (int k = 0; k < pDoc->m_inW; k++) {
			R = G = B = pDoc->m_inImage[i][k];
			pDC->SetPixel(k + 5, i + 5, RGB(R, G, B));
		}
	}
	for (int i = 0; i < pDoc->m_outH; i++) {
		for (int k = 0; k < pDoc->m_outW; k++) {
			R = G = B = pDoc->m_outImage[i][k];
			pDC->SetPixel(k + pDoc->m_inW + 10, i + 5, RGB(R, G, B));
		}
	}
}


// CGrayScaleImageProcessingRC1View 인쇄

BOOL CGrayScaleImageProcessingRC1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CGrayScaleImageProcessingRC1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CGrayScaleImageProcessingRC1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}


// CGrayScaleImageProcessingRC1View 진단

#ifdef _DEBUG
void CGrayScaleImageProcessingRC1View::AssertValid() const
{
	CView::AssertValid();
}

void CGrayScaleImageProcessingRC1View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGrayScaleImageProcessingRC1Doc* CGrayScaleImageProcessingRC1View::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGrayScaleImageProcessingRC1Doc)));
	return (CGrayScaleImageProcessingRC1Doc*)m_pDocument;
}
#endif //_DEBUG


// CGrayScaleImageProcessingRC1View 메시지 처리기


void CGrayScaleImageProcessingRC1View::OnEqualImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnEqualImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnAddImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnAddImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnOpImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnOpImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnBlackImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnBlackImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnOrImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnOrImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnAndImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnAndImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnXorImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnXorImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnInvalueImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnInvalueImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnEmbossImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnEmbossImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnBlurImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnBlurImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnSharpningImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnSharpningImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnHifilImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnHifilImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnHoredgeImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnHoredgeImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnVeredgeImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnVeredgeImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnSimcalImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnSimcalImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnDivcalImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnDivcalImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnZoomoutImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnZoomoutImage();
	Invalidate(TRUE);

}


void CGrayScaleImageProcessingRC1View::OnZoominImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnZoominImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnRotateImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnRotateImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnRotate2Image()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnRotate2Image();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnUdmirrorImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnUdmirrorImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnLrmirrorImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnLrmirrorImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnStreachImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnStreachImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnEddinImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnEddinImage();
	Invalidate(TRUE);
}


void CGrayScaleImageProcessingRC1View::OnHistoequalImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CGrayScaleImageProcessingRC1Doc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	pDoc->OnHistoequalImage();
	Invalidate(TRUE);
}
