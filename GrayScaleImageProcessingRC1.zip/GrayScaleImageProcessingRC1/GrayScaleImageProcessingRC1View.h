﻿
// GrayScaleImageProcessingRC1View.h: CGrayScaleImageProcessingRC1View 클래스의 인터페이스
//

#pragma once


class CGrayScaleImageProcessingRC1View : public CView
{
protected: // serialization에서만 만들어집니다.
	CGrayScaleImageProcessingRC1View() noexcept;
	DECLARE_DYNCREATE(CGrayScaleImageProcessingRC1View)

// 특성입니다.
public:
	CGrayScaleImageProcessingRC1Doc* GetDocument() const;

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual void OnDraw(CDC* pDC);  // 이 뷰를 그리기 위해 재정의되었습니다.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 구현입니다.
public:
	virtual ~CGrayScaleImageProcessingRC1View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEqualImage();
	afx_msg void OnAddImage();
	afx_msg void OnOpImage();
	afx_msg void OnBlackImage();
	afx_msg void OnOrImage();
	afx_msg void OnAndImage();
	afx_msg void OnXorImage();
	afx_msg void OnInvalueImage();
	afx_msg void OnEmbossImage();
	afx_msg void OnBlurImage();
	afx_msg void OnSharpningImage();
	afx_msg void OnHifilImage();
	afx_msg void OnHoredgeImage();
	afx_msg void OnVeredgeImage();
	afx_msg void OnSimcalImage();
	afx_msg void OnDivcalImage();
	afx_msg void OnZoomoutImage();
	afx_msg void OnZoominImage();
	afx_msg void OnRotateImage();
	afx_msg void OnRotate2Image();
	afx_msg void OnUdmirrorImage();
	afx_msg void OnLrmirrorImage();
	afx_msg void OnStreachImage();
	afx_msg void OnEddinImage();
	afx_msg void OnHistoequalImage();
};

#ifndef _DEBUG  // GrayScaleImageProcessingRC1View.cpp의 디버그 버전
inline CGrayScaleImageProcessingRC1Doc* CGrayScaleImageProcessingRC1View::GetDocument() const
   { return reinterpret_cast<CGrayScaleImageProcessingRC1Doc*>(m_pDocument); }
#endif

