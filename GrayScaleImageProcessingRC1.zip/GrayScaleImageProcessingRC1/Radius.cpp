﻿// Radius.cpp: 구현 파일
//

#include "pch.h"
#include "GrayScaleImageProcessingRC1.h"
#include "afxdialogex.h"
#include "Radius.h"


// CRadius 대화 상자

IMPLEMENT_DYNAMIC(CRadius, CDialog)

CRadius::CRadius(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_RADIUS, pParent)
	, m_Radius(0)
{

}

CRadius::~CRadius()
{
}

void CRadius::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_RADIUS, m_Radius);
	DDV_MinMaxInt(pDX, m_Radius, 0, INT_MAX);
}


BEGIN_MESSAGE_MAP(CRadius, CDialog)
END_MESSAGE_MAP()


// CRadius 메시지 처리기
